Name: Timothy Lin
JHUED: tlin56
Class year: 2026
major/minor: Computer Science (Maybe double majoring AMS)

This is Timothy Lin's personal repository for Intermediate Programming at JHU for Fall 2022
Timothy is enrolled in Intermediate Programming section 3

